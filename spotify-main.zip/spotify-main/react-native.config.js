module.exports = {
    dependencies: {
        'react-native-firebase': {
            platforms: {
                ios: null,
            },
        },
        'react-native-callkeep': {
            platforms: {
                android: null,
            },
        },
    },
};
