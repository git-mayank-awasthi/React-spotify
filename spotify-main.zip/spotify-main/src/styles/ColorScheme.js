/*
 * Copyright (c) 2011-2018, Zingaya, Inc. All rights reserved.
 */

'use strict';

const COLOR_SCHEME = {
    LIGHT: 'light-content',
    DARK: 'dark-content',
};

export default COLOR_SCHEME;
